
#include<stdio.h>

 void main() {
 
 	for(float num=0.0f; num<=10.0f; num++) {
		
		
		printf("%.2f\t",num);

	
	}
		printf("\n");
 
 }

