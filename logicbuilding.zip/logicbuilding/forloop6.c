
#include<stdio.h>

 void main() {
 
	 int sum=0;
	 for(int i=1; i<=15; i++)
	 {
	 	sum=sum+i;
	 }

	 printf("Sum =%d\n",sum);

 
 }
