
#include<stdio.h>

 void main() {
 
 	for(float num=0.0f; num<=10.0f; num=num + 0.20f) {
		
		printf("%f\t",num);
	
	}

 
 }

