
#include<stdio.h>

  void main() {
  
  int x=100, y=200, ans=0;


  ans=x>y;
  printf("%d\n",ans);
  
  ans=x<y;
  printf("%d\n",ans);
  
  ans=x==y;
  printf("%d\n",ans);
  
  ans=x>=y;
  printf("%d\n",ans);
  
  ans=x<=y;
  printf("%d\n",ans);
  

  ans=x==y;
  printf("%d\n",ans);
  

  ans=x!=y;
  printf("%d\n",ans);
  

  
  


  







  }
