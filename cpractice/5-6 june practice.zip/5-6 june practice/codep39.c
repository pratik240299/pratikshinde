
#include<stdio.h>

  void main() {
  
  int ans=0;
  ans=4*3+12-23*10+20;

  printf("%d\n",ans);
  
  }
