


#include<stdio.h>

void main() {

  int a=2, b=34,c=10,ans=0;

  ans=++a + b++ +2 + ++c;

  printf("%d %d %d %d\n",a,b,ans,c);



}


