


#include<stdio.h>

void main() {

  int a=2, b=34,ans=0;

  ans=++a + b++ +2;

  printf("%d %d %d\n",a,b,ans);



}


