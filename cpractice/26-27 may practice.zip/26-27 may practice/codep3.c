


#include<stdio.h>

void main() {

  int a=2, b=34,c=15,d=20,ans=0;

  ans=++a + b++ +2 + c++ + ++d;

  printf("%d %d %d\n",a,b,ans);



}


