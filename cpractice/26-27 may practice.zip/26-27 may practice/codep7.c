


#include<stdio.h>

void main() {

  int a=2, b=3,c=15,ans=0;
  float e=5.5, f=10;

  ans=++a + b++ +2 + c++ + ++e - --f;
  

  printf(" %d %d %d %f %f %d\n",a,b,c,e,f,ans);
  


   }


