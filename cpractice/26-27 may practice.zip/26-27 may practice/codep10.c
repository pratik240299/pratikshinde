


#include<stdio.h>

void main() {

  int a=2, b=3,c=15,ans=0;
  float e=5.5, f=10;
 char grade='A';

  ans=++a+b+++2+c+++e---f;
  

  printf(" %d %d %d %f %f %d\n",a,b,c,e,f,ans);
  printf("grade");

   int pants=200;
  float jackets=500;
  char tshirt='M';
  
  printf("\n%d\n",pants);
  printf("%f\n",jackets);
  printf("%c\n",tshirt);

 
 }


