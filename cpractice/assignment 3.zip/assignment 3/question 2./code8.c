

#include<stdio.h>

   void main() {
   
    int x=45,y=33,ans=0;
    ans= x | y;

    printf("%d\n",ans);
   
   }
