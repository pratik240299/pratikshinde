
#include<stdio.h>
  void main()  {
  
  int p=18,ans=0;
  ans=p<<5;

  printf("%d\n",ans);
  
  
  }
