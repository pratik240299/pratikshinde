#include<stdio.h>

   void main() {
    int a=58,ans=0;
    ans= a<<3;

    printf("%d\n",ans);
   
   
   }
