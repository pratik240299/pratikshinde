
#include<stdio.h>
  void main()  {
  
  int s=95,ans=0;
  ans=s<<2;

  printf("%d\n",ans);
  
  
  }
