
#include<stdio.h>

  void main() {

    int x=23,y=77,ans=0;
    ans=x | y;

    printf("%d\n",ans);
  
  }
