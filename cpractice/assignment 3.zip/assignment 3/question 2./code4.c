

#include<stdio.h>

   void main() {
   
      int x=10,ans=0;
      ans= x<<4;

      printf("%d\n",ans);
   
   }
