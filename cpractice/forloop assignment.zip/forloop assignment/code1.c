
#include<stdio.h>

 void main() {
 
 	int i;
	printf("enter the number: ");
	scanf("%d",&i);

	for(i;i<=30;i=i+3)
	{
		printf("%d\n",i);
	}
 
 }
