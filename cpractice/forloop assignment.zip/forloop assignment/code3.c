
#include<stdio.h>

 void main() {

	 int i;
	 printf("enter number 50: ");
	 scanf("%d",&i);
 
 	for(i;i<=70;i++)
	{
		if(i%2==0)
			printf("%d is even number\n",i);
	}
 }

