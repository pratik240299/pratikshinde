
#include<stdio.h>

 void main() {
 
 	char ch;

	printf("Enter the character:");
	scanf("%c",&ch);

	for(ch;ch>=106;ch--)
	{
		printf("%c\n",ch);
	}	
 }
