
#include<stdio.h>

 void main() {

	 int i;
	 printf("enter number 1:  ");

	 scanf("%d",&i);
 
 	for(i;i<=50;i++)
	{
		if(50%i==0)
			printf("%d is divisor of 50\n",i);
	}
 }

