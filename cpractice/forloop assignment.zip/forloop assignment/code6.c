
#include<stdio.h>

void main() {

	int i;

	printf("enter the number: ");
	scanf("%d",&i);

	for(i;i<=90;i++)
	{
		printf("%c=%c\n",i,i+32);
	}


}
