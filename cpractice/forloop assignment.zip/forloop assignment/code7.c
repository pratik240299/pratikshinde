
#include<stdio.h>

 void main() {
 
 	int i,j;

	printf("Enter a number:");
	scanf("%d",&i);
	printf("Enter the limit:");
	scanf("%d",&j);

	for(i;i<=j;i=i+6)
	{
		printf("%d\n",i);
	}

 
 }
