
#include<stdio.h>

 void main() {
 
	 int i;

	 printf("enter the number: ");
	 scanf("%d",&i);

	 for(i;i>=15;i=i-2)
	 {
	 	printf("%d\n",i);
	 }
 }

