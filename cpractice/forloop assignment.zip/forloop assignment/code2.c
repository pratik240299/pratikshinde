
#include<stdio.h>

 void main() {

	 int i;
	 printf("enter number 20: ");
	 scanf("%d",&i);
 
 	for(i;i<=40;i++)
	{
		if(i%2!=0)
			printf("%d is odd number\n",i);
	}
 }

