
#include<stdio.h>
 
 void main() {
 
 	int i;

	printf("enter number 65: ");
	scanf("%d",&i);

	for(i;i<=128;i++)
	{
		printf("%c=%d\n",i,i);
	}
 
 }

