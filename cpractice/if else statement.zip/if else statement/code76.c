
#include<stdio.h>

 void main() {
 
   	int marks=80;
	int computer=90;

		if(marks>70)
		   {
		   	printf("fc/morden\n");

			if(computer>80)
				printf("fc-bcs\n");
			else
				printf("modern-cs\n");
		   }
		else
			printf("sports man\n");


             }
