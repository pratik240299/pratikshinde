
#include<stdio.h>

 void main() {
 
	 int username = 123;
	 int password = 456;

	 	if(username == 123 && password == 456)
		   {
			printf("sucessfully login\n");
		   }
	        else
			printf("invaild login\n");

             }
