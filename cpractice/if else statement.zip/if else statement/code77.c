
#include<stdio.h>

 void main() {
 
      	int marks=90;

		if(marks>80)
			printf("fc\n");
		else if(marks>70 && marks<80)
			printf("modern\n");
		else if(marks>60 && marks<70)
			printf("garware\n");
		else
			printf("jspm-ntc");

            }
