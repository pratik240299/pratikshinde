
#include<stdio.h>

   int a=10;                 // Non-Executable statment.

  void main() {
	  
	  int b=20;         // Executable statement.
          printf("%d\n",a);
  
  
  }
