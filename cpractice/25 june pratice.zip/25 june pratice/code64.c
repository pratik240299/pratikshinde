
#include<stdio.h>

   void main () {

  // Simple statement :

       int percentage=95;	   
  
       if(percentage>90)
         printf("i will get bike\n");
   
   }
