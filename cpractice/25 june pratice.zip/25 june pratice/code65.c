
#include<stdio.h>

   void main() {

  // Simple statement :

       int percentage=95;	   
  
       if(percentage>90);
         printf("i will get bike\n");

  // Compound statement :
  
       int marks=87;

       if (marks>90)
          {
         printf("i will get r15 bike");
          }	 

	 else if(marks<90 && marks>85)
	 {
	   printf(" i will get nike shoes");
	 } 
	 else(marks<85)
	 {
	  printf(" i will g-shock watch");
	 }
       

   }
