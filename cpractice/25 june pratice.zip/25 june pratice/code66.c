

#include<stdio.h>

  void main() {
  
  int a;      //defination statement
  int b=10;   // defination statement

 extern int c=20;  //declaration statement

  
  }

