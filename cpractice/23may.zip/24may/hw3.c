

#include<stdio.h>
  

  void main() {
  
  int x=10,y=20;

    printf("%d\n%d\n",x,y);
     
    x=x+2;
    y+y+3;
   
     printf("%d\n%d\n",x,y);
  
  }
