

#include<stdio.h>
  
  void main()  {
  
     int x=15,y=20;

     printf("%d\n",x+y);
     printf("%d\n",x-y);
     printf("%d\n",x/y);
     printf("%d\n",x%y);
  
  }
