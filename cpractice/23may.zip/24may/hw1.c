

#include<stdio.h>

  void main() {
  
      int a=20;

        printf("%d\n",a);
        printf("%d\n",++a);
        printf("%d\n",a++);
        printf("%d\n",a);

       }

