
#include<stdio.h>

  void main() {
  
      int a=65;

         switch(a) {
     
	             case 'A':
		     printf("A- Case");
		     break;

                     case 'B':
		     printf("B-Case");
	             break;

		     case 65:
		     printf("65-Case");
		     break;

  
                  }
  
  
              }
