#include<stdio.h>

  void main() {
  	char ch='D';
     	 switch(ch) {
      
	           case 65:
			   printf("pratik\n");
			   break;

	           case 10:
			   printf("SHINDE\n");
			   break;

		   default :
      			   printf("no matching\n");
                           break;

     	       	   }
  
 	      }
