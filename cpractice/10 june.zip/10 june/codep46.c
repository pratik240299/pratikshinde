

#include<stdio.h>

  void main() {
  
    int x=4,y=5,ans=0;
    ans=x & y;

    printf("%d\n",ans);

  }
