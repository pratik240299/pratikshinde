
#include<stdio.h>

 void main()  {
  
      int a=5,b=10,c=0;

      	       if(a && b)
		       printf("core2web\n");
      	       if(b && c)
		       printf("bits\n");
      	       if(b || c)
		       printf("pratik\n");

             }
