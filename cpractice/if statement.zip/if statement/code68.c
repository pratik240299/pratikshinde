
#include<stdio.h>

void main() {

     int marks=95;

            if(marks > 90)
		    	printf("bike\n");
	                
            }
           
