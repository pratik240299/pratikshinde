
#include<stdio.h>

 void main() {
  
	 int a=10;

	 	if(a>20); {

			printf("welcome\n");
			printf("pratik\n");

		          } 
            }
