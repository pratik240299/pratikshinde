
#include<stdio.h>

void main() {

     int marks=95;

//compound statement

            if(marks > 90) {
		    	printf("bike\n");
 	        	printf("laptop\n");
			printf("iphone\n");	
                          }
           }
