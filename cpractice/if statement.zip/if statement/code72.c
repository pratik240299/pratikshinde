
#include<stdio.h>

 void main() {
   
	 int a=10;

	 	if(a!=10) 
			printf("equal\n");
			printf("end of if\n");
 
            }
