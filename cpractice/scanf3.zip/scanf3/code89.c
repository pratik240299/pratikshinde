
#include<stdio.h>

 void main() {
 
 	int x,y;

	printf("enter the 2 value:");
	scanf("%d %d",&x,&y);

	if(x>y)
		printf("x is greater");

	printf("out of if\n");
 }
