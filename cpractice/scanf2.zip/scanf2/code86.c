#include<stdio.h>

 void main() {
 
 	char ch;

	printf("enter the character:");
	scanf("%c",&ch);

	printf("%c\n",ch);
        printf("%d\n",ch);

 }
