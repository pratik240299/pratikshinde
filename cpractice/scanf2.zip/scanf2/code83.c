
#include<stdio.h>

 void main() {
 
 	float val;
	printf("enter float valuei:");
	scanf("%f",&val);

	printf("%f\n",val);

 }
