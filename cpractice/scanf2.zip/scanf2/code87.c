#include<stdio.h>

 void main() {
 
 	char ch1,ch2;

	printf("enter the two character:");
	scanf("%c %c",&ch1,&ch2);

	printf("value of 1=%c\nvalue 0f 2=%c\n",ch1,ch2);
   //     printf("%d\n",ch);

 }
