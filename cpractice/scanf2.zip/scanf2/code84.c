
#include<stdio.h>

 void main() {
 
 	float val1,val2;
	printf("enter two float value:");
	scanf("%f %f",&val1,&val2);

	printf("value1=%f\nvalue2=%f\n",val1,val2);

 }
