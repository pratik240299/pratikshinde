

#include<stdio.h>

  void main()  {
  
  int a=10,b=15,ans=0;
   
  ans=++a + b;
   
  printf("%d %d %d\n",a,b,ans);
  
  
  }
