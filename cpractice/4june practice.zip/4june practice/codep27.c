

#include<stdio.h>

void main() {
   
   int ans=0;
 ans=8+4/2-5;

  printf("%d\n",ans);   
  

}




