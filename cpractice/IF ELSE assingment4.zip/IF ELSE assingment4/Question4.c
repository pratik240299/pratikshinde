
#include<stdio.h>
#include<stdbool.h>
  void main() {
  
  _Bool val=false, var=true;

  if (val); {
  	printf("true\n");
  }
  if(var) {
  	printf("false\n");
  }
  
  }  
