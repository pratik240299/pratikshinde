
#include<stdio.h>

  void main() {
  
  float x=5.2,y=10.5;

  if(x==5.2) {
  	printf("x:%f\n",x);    //  write %f at the place of %d as it is float value
   }	                       // error : curle bracket was  not close 
  if (y==10.5) {
  	printf("y:%f\n",y);	
  
  }
  
  
  }
