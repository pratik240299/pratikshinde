

#include<stdio.h>
 
void main() {

      int num = 20;

     if(num>20){                                                // FALSE
        	printf("num is greater than 20");
     }

      printf("num :%d\n",num);                                


}

// explaintion : as th number int num 20 is not greater than 20 therefore if conditiom is false,
// and outside if is print.
