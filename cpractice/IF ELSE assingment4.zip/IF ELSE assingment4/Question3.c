
  
 #include<stdio.h>

   void main()  {
   
    int ilc=15,olc=25;
     
    if(olc >ilc)  {                  //  if condition is itrue
    
    	printf("olc:%d\n",olc);
    
    }
    if(ilc < olc);{                  // if condition is true
      printf("ilc:%d\n",ilc);
    
    
    }
    printf("olc:%d\n",olc);         // outside if will always print
    printf("ilc: %d\n",ilc);
   
   
   }
