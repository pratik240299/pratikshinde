
#include<stdio.h>

 void main() {
 
 	for(int i=5;i>=1;i--)
	{
		printf("%d\n",i);
	}
 }
