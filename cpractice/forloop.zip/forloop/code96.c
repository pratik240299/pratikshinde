
#include<stdio.h>

 void main() {
 
 	for(int i = 0;i<=20;i++)
	{
		if(i % 2 == 0)
			printf("even = %d\n",i);
		else
			printf("odd = %d\n",i);
	}
 }
