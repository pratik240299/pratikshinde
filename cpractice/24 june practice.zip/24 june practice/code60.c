

#include <stdio.h>

 void main(){
 
 int a=10;
 int b=20;
 int c=30;

  int ans= 3<<a / b>>3 + c;
 

 printf("%d\n",~(a));
 printf("%d\n",~(b));
 printf("%d\n",~(c));
 printf("%d\n",~(ans));
 
 }
