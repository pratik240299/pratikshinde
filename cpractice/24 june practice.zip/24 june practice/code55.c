

#include <stdio.h>

 void main(){
 
 int a=-100;
 int b=-50;

  int ans= a + b;

printf("%d\n",~(a));
printf("%d\n",~(b));
 printf("%d\n",~(ans));
 
 }
