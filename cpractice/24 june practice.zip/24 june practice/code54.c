

#include <stdio.h>

 void main(){
 
 int a=-20;
 int b=30;

  int ans= a + b;

printf("%d\n",~(a));
printf("%d\n",~(b));
 printf("%d\n",~(ans));
 
 }
