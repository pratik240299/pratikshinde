

#include <stdio.h>

 void main(){
 
 int a=100;
 int b=200;

  int ans= a>>2 / b>>3;
 

 printf("%d\n",~(a));
 printf("%d\n",~(b));
 printf("%d\n",~(ans));
 
 }
