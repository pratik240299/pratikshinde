#include<stdio.h>

 void main() {
 
 	int a,b;

	printf("enter number of a:");
	scanf("%d",&a);
	printf("enter number of b:");
	scanf("%d",&b);


	printf("a=%d\n",a);
	printf("b=%d\n",b);
//	printf("%p\n",&a);
//	printf("%p\n",&a);
 }
