#include<stdio.h>

 void main() {
 
 	int a;

	printf("enter number:");
	scanf("%d",&a);

	printf("a=%d\n",a);
//	printf("%p\n",&a);
 }
