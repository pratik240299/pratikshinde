#include<stdio.h>

 void main() {
 
 	int a,b;
	int ans;
	printf("enter the number for a and b :");
	scanf("%d %d",&a,&b);

	ans=a+b;
	printf("ans=%d\n",ans);
 }
