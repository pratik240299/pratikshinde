#include<stdio.h>

 void main() {
 
 	int a,b;
	int ans;
	printf("enter the number for a and b :");
	scanf("%d %d",&a,&b);

	//addition
	ans=a+b;
	printf("add=%d\n",ans);

	//substraction
	ans= a-b ;
	printf("sub=%d\n",ans);

	//multiplication
	ans= a/b;
	printf("mult=%d\n",ans);

 
 }
