#include<stdio.h>

 void main() {
 
 	int a,b;

	printf("enter the number for a and b :");
	scanf("%d %d",&a,&b);

	
	printf("ans=%d\n",a+b);
 }
