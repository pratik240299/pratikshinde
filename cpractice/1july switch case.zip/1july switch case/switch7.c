
#include<stdio.h>

 void main() {
            
 	char ch='D';

		switch(ch) {

			default:
				printf("none of this\n");
		         	break;	
			case 65:
				printf("answer 65\n");
				break;	
			case 40:
				printf("answer 40\n");	
				break;	
			case 70:
				printf("answer 70\n");	
				break;	
			case 60:
				printf("answer 60\n");	
				break;	
			case 80:
				printf("answer 80\n");	
				break;	
			

		          } 
              }
