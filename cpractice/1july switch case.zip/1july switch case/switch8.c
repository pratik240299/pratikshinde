
#include<stdio.h>

 void main() {
            
 	int x=10;
	int y=20;
	int ans=x+y;

		switch(ans){

			case 65:
				printf("answer 65\n");
				break;	
			case 30:
				printf("answer 30\n");	
				break;	
			case 70:
				printf("answer 70\n");	
				break;	
			case 60:
				printf("answer 60\n");	
				break;	
			case 80:
				printf("answer 80\n");	
				break;	
			default:
				printf("none of this\n");	
			

		          } 
              }
