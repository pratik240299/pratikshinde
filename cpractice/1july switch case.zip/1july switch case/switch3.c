
#include<stdio.h>

 void main() {
            
 	char ch='a';

		switch(ch) {
		          
			case 'a':
				printf("answer a\n");
				break;	
			case 'b':
				printf("answer b\n");	
				break;	
			case 'c':
				printf("answer c\n");	
				break;	
			case 'd':
				printf("answer d\n");	
				break;	
			case 'e':
				printf("answer e\n");	
				break;	
			

		          } 
              }
