
#include<stdio.h>

 void main() {
            
 	int a =65;

		switch(a) {
		          
			case 'A' :
				printf("answer A\n");
				break;	
			case 4:
				printf("answer 4\n");	
				break;	
			case 'B':
				printf("answer B\n");	
				break;	
			case 6:
				printf("answer 6\n");	
				break;	
			case 'C':
				printf("answer C\n");	
				break;	
			

		          } 
              }
