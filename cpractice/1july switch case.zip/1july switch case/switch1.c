
#include<stdio.h>

 void main() {
            
 	int a=10;

		switch(a) {
		          
			case 2:
				printf("answer 2\n");	
			case 4:
				printf("answer 4\n");	
			case 10:
				printf("answer 10\n");	
			case 6:
				printf("answer 6\n");	
			case 20:
				printf("answer 20\n");	

		          } 
              }
